setwd("C:\\Users\\Nandun Senaratne\\OneDrive\\Desktop\\IT24102230 PS LAB5")
Delivery.Times<-read.table("Exercise - Lab 05.txt",header = TRUE)
head(Delivery.Times)
hist(Delivery.Times$Delivery,
     breaks = 9,
     xlim = c(20,70),
     main = "histogram of Delivery Time",
     xlab = "Delivery Time",right = TRUE)

# Based on the histogram, distribution is positively skewed

# Cut delivery times into intervals
delivery_cut <- cut(Delivery.Times$Delivery, breaks=seq(20, 70, by=5))
# Frequency table
freq_table <- table(delivery_cut)
# Cumulative frequency
cum_freq <- cumsum(freq_table)
# Midpoints of bins
bin_midpoints <- seq(22.5, 67.5, by=5)
# Plot ogive (cumulative frequency polygon)
plot(bin_midpoints, cum_freq, type="o",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")
